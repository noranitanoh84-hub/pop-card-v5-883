// Global State
let allData = [];
let filteredData = [];
let allTasks = [];
let filteredTasks = [];
let currentPage = 1;
const rowsPerPage = 10;
let sortColumn = '';
let sortDirection = 'asc';
let selectedRows = new Set();
let recentActivity = [];
let currentCalendarDate = new Date(2025, 11, 1); // December 2025
let colorLabels = {};

// Constants
const months = ['JAN', 'FEB', 'MAC', 'APRIL', 'MEI', 'JUN', 'JUL', 'OGO', 'SEP', 'OKT', 'NOV', 'DIS'];
const monthsFull = ['Januari', 'Februari', 'Mac', 'April', 'Mei', 'Jun', 'Julai', 'Ogos', 'September', 'Oktober', 'November', 'Disember'];
const departments = ['GROCERY', 'FRESH', 'HARDLINE', 'GMS', 'APPAREL'];
const branches = ['MELAKA', 'KUALA LUMPUR', 'SELANGOR', 'NEGERI SEMBILAN', 'JOHOR', 'PAHANG', 'TERENGGANU', 'KELANTAN', 'PERLIS', 'KEDAH', 'PENANG', 'PERAK', 'LABUAN', 'PUTRAJAYA', 'SABAH', 'SARAWAK'];
const storeTypes = ['HYPER', 'EMPO', 'SUPER', 'MyMydin'];

const colorSystem = {
    red: { label: 'Maaf', hex: '#FF5459', meaning: 'Urgent/High Priority' },
    orange: { label: 'Dalam Proses', hex: '#E68161', meaning: 'In Progress' },
    yellow: { label: 'Menunggu', hex: '#F5D547', meaning: 'Pending' },
    green: { label: 'Selesai', hex: '#22C55E', meaning: 'Completed' },
    blue: { label: 'Catatan', hex: '#3B82F6', meaning: 'Information' },
    purple: { label: 'Mesyuarat', hex: '#9333EA', meaning: 'Important Date' },
    gray: { label: 'Batal', hex: '#6B7280', meaning: 'Cancelled' },
    brown: { label: 'Lain-Lain', hex: '#92400E', meaning: 'Other' }
};

// Sample Data
const initialData = [
    {id: 1, bulan: 'JAN', jabatan: 'GROCERY', jenisStore: 'HYPER', promo: '150', slash: '225', cmp: '50', combo: '5', cawangan: 'KUALA LUMPUR', tempoh: '1-31 Jan 2025', status: 'active', starred: false},
    {id: 2, bulan: 'JAN', jabatan: 'FRESH', jenisStore: 'SUPER', promo: '120', slash: '180', cmp: '40', combo: '3', cawangan: 'MELAKA', tempoh: '1-31 Jan 2025', status: 'active', starred: false},
    {id: 3, bulan: 'FEB', jabatan: 'HARDLINE', jenisStore: 'EMPO', promo: '200', slash: '300', cmp: '60', combo: '8', cawangan: 'SELANGOR', tempoh: '1-28 Feb 2025', status: 'pending', starred: false},
    {id: 4, bulan: 'FEB', jabatan: 'GMS', jenisStore: 'MyMydin', promo: '180', slash: '270', cmp: '55', combo: '6', cawangan: 'JOHOR', tempoh: '1-28 Feb 2025', status: 'active', starred: false},
    {id: 5, bulan: 'MAC', jabatan: 'APPAREL', jenisStore: 'HYPER', promo: '160', slash: '240', cmp: '52', combo: '4', cawangan: 'PENANG', tempoh: '1-31 Mac 2025', status: 'active', starred: false}
];

const initialTasks = [
    {id: 1, date: '2025-12-01', title: 'Serah POP Card G1', description: 'Hantar POP card jabatan grocery ke pusat', color: 'green', colorLabel: 'Sudah Serah', time: '09:00', priority: 'High', completed: true},
    {id: 2, date: '2025-12-02', title: 'Update Fresh Stock', description: 'Kemaskini stok bahagian fresh', color: 'orange', colorLabel: 'Dalam Proses', time: '10:30', priority: 'High', completed: false},
    {id: 3, date: '2025-12-03', title: 'Laporan HARDLINE', description: 'Siapkan laporan mingguan hardline', color: 'yellow', colorLabel: 'Menunggu', time: '14:00', priority: 'Medium', completed: false},
    {id: 4, date: '2025-12-04', title: 'Mesyuarat Pengurusan', description: 'Mesyuarat bulanan dengan semua pengurus', color: 'purple', colorLabel: 'Mesyuarat', time: '11:00', priority: 'High', completed: false},
    {id: 5, date: '2025-12-05', title: 'Periksa Promo Display', description: 'Periksa paparan promosi di cawangan utama', color: 'blue', colorLabel: 'Catatan', time: '15:00', priority: 'Medium', completed: false},
    {id: 6, date: '2025-12-08', title: 'Serah GMS', description: 'Hantar data GMS sudah siap', color: 'red', colorLabel: 'Maaf', time: '08:00', priority: 'High', completed: false},
    {id: 7, date: '2025-12-10', title: 'Analisis Data', description: 'Analisis data penjualan bulan November', color: 'green', colorLabel: 'Selesai', time: '16:00', priority: 'Medium', completed: true},
    {id: 8, date: '2025-12-12', title: 'Training APPAREL', description: 'Sesi latihan produk apparel baru', color: 'purple', colorLabel: 'Mesyuarat', time: '10:00', priority: 'High', completed: false},
    {id: 9, date: '2025-12-15', title: 'Inventory Check', description: 'Pemeriksaan inventori akhir tahun', color: 'gray', colorLabel: 'Batal', time: '09:00', priority: 'Low', completed: false}
];

// Initialize
function init() {
    allData = [...initialData];
    filteredData = [...allData];
    allTasks = [...initialTasks];
    filteredTasks = [...allTasks];
    colorLabels = JSON.parse(JSON.stringify(colorSystem));
    
    populateFilters();
    updateStats();
    renderTable();
    renderCalendar();
    renderTasksList();
    populateColorFilters();
    renderColorSettings();
    loadTheme();
    loadSidebarState();
    updateActivityFeed();
}

// Navigation
function navigateTo(page) {
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
    
    const pageElement = document.getElementById(page + 'Page');
    if (pageElement) {
        pageElement.classList.add('active');
        event.target.closest('.nav-item').classList.add('active');
        
        // Initialize charts when navigating to analytics
        if (page === 'analytics') {
            setTimeout(() => initAnalyticsCharts(), 100);
        } else if (page === 'dashboard') {
            setTimeout(() => initDashboardCharts(), 100);
        }
    }
}

// Sidebar Toggle with localStorage persistence
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    sidebar.classList.toggle('collapsed');
    
    // Save state to variable (not localStorage due to sandbox restrictions)
    window.sidebarCollapsed = sidebar.classList.contains('collapsed');
    
    // Update activity
    const state = sidebar.classList.contains('collapsed') ? 'TUTUP' : 'BUKA';
    addActivity(`Sidebar ${state}`);
}

// Load sidebar state on init
function loadSidebarState() {
    if (window.sidebarCollapsed) {
        document.getElementById('sidebar').classList.add('collapsed');
    }
}

// Populate Filters
function populateFilters() {
    const filters = {
        filterMonth: months,
        bulan: months,
        filterDept: departments,
        jabatan: [...departments, '__custom__'],
        filterStore: storeTypes,
        jenisStore: [...storeTypes, '__custom__'],
        filterBranch: branches,
        cawangan: [...branches, '__custom__']
    };
    
    Object.keys(filters).forEach(id => {
        const select = document.getElementById(id);
        if (select) {
            filters[id].forEach(value => {
                const option = document.createElement('option');
                option.value = value === '__custom__' ? value : value;
                option.textContent = value === '__custom__' ? 'Lain-Lain (Custom)' : value;
                select.appendChild(option);
            });
        }
    });
}

function populateColorFilters() {
    const select = document.getElementById('taskColorFilter');
    Object.keys(colorSystem).forEach(color => {
        const option = document.createElement('option');
        option.value = color;
        option.textContent = `${getColorEmoji(color)} ${colorSystem[color].label}`;
        select.appendChild(option);
    });
}

function getColorEmoji(color) {
    const emojis = {
        red: '🔴', orange: '🟠', yellow: '🟡', green: '🟢',
        blue: '🔵', purple: '🟣', gray: '⚫', brown: '🟤'
    };
    return emojis[color] || '';
}

// Update Statistics
function updateStats() {
    document.getElementById('totalRecords').textContent = allData.length;
    document.getElementById('activePromos').textContent = allData.filter(d => d.status === 'active').length;
    document.getElementById('pendingTasks').textContent = allTasks.filter(t => !t.completed).length;
    
    const uniqueMonths = [...new Set(allData.map(d => d.bulan))].length;
    const avgPerMonth = uniqueMonths > 0 ? (allData.length / uniqueMonths).toFixed(1) : 0;
    document.getElementById('avgPerMonth').textContent = avgPerMonth;
}

// Dashboard Charts
let promoTrendChart, deptPerformanceChart;

function initDashboardCharts() {
    const isDark = document.documentElement.getAttribute('data-color-scheme') === 'dark';
    const textColor = isDark ? '#f5f5f5' : '#13343B';
    const gridColor = isDark ? 'rgba(119, 124, 124, 0.2)' : 'rgba(94, 82, 64, 0.2)';
    
    // Promo Trend
    const promoCtx = document.getElementById('promoTrendChart');
    if (promoCtx) {
        if (promoTrendChart) promoTrendChart.destroy();
        const monthlyData = {};
        months.forEach(month => {
            const monthData = allData.filter(d => d.bulan === month);
            monthlyData[month] = monthData.reduce((sum, d) => sum + parseInt(d.promo || 0), 0);
        });
        
        promoTrendChart = new Chart(promoCtx, {
            type: 'line',
            data: {
                labels: months,
                datasets: [{
                    label: 'Jumlah Promo',
                    data: months.map(m => monthlyData[m] || 0),
                    borderColor: '#21808D',
                    backgroundColor: 'rgba(33, 128, 141, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { labels: { color: textColor } } },
                scales: {
                    y: { beginAtZero: true, ticks: { color: textColor }, grid: { color: gridColor } },
                    x: { ticks: { color: textColor }, grid: { color: gridColor } }
                }
            }
        });
    }
    
    // Department Performance
    const deptCtx = document.getElementById('deptPerformanceChart');
    if (deptCtx) {
        if (deptPerformanceChart) deptPerformanceChart.destroy();
        const deptData = {};
        departments.forEach(dept => {
            const deptRecords = allData.filter(d => d.jabatan === dept);
            deptData[dept] = deptRecords.reduce((sum, d) => sum + parseInt(d.promo || 0) + parseInt(d.slash || 0), 0);
        });
        
        deptPerformanceChart = new Chart(deptCtx, {
            type: 'bar',
            data: {
                labels: departments,
                datasets: [{
                    label: 'Jumlah Prestasi',
                    data: departments.map(d => deptData[d] || 0),
                    backgroundColor: ['#1FB8CD', '#FFC185', '#B4413C', '#ECEBD5', '#5D878F']
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { labels: { color: textColor } } },
                scales: {
                    y: { beginAtZero: true, ticks: { color: textColor }, grid: { color: gridColor } },
                    x: { ticks: { color: textColor }, grid: { color: gridColor } }
                }
            }
        });
    }
}

// Analytics Charts
function initAnalyticsCharts() {
    const isDark = document.documentElement.getAttribute('data-color-scheme') === 'dark';
    const textColor = isDark ? '#f5f5f5' : '#13343B';
    const gridColor = isDark ? 'rgba(119, 124, 124, 0.2)' : 'rgba(94, 82, 64, 0.2)';
    
    // Tasks Completed by Month
    const tasksCompletedCtx = document.getElementById('tasksCompletedChart');
    if (tasksCompletedCtx) {
        new Chart(tasksCompletedCtx, {
            type: 'line',
            data: {
                labels: monthsFull,
                datasets: [{
                    label: 'Tugas Selesai',
                    data: [5, 8, 12, 10, 15, 13, 18, 20, 16, 14, 19, 7],
                    borderColor: '#22C55E',
                    backgroundColor: 'rgba(34, 197, 94, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { labels: { color: textColor } } },
                scales: {
                    y: { beginAtZero: true, ticks: { color: textColor }, grid: { color: gridColor } },
                    x: { ticks: { color: textColor }, grid: { color: gridColor } }
                }
            }
        });
    }
    
    // Tasks by Color
    const tasksByColorCtx = document.getElementById('tasksByColorChart');
    if (tasksByColorCtx) {
        const colorCounts = {};
        Object.keys(colorSystem).forEach(c => colorCounts[c] = 0);
        allTasks.forEach(t => colorCounts[t.color]++);
        
        new Chart(tasksByColorCtx, {
            type: 'doughnut',
            data: {
                labels: Object.keys(colorSystem).map(c => colorSystem[c].label),
                datasets: [{
                    data: Object.values(colorCounts),
                    backgroundColor: Object.keys(colorSystem).map(c => colorSystem[c].hex)
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { labels: { color: textColor } } }
            }
        });
    }
    
    // Monthly Performance
    const monthlyPerfCtx = document.getElementById('monthlyPerformanceChart');
    if (monthlyPerfCtx) {
        new Chart(monthlyPerfCtx, {
            type: 'bar',
            data: {
                labels: months,
                datasets: [{
                    label: 'Prestasi',
                    data: months.map((m, i) => (i + 1) * 150 + Math.random() * 50),
                    backgroundColor: '#1FB8CD'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { labels: { color: textColor } } },
                scales: {
                    y: { beginAtZero: true, ticks: { color: textColor }, grid: { color: gridColor } },
                    x: { ticks: { color: textColor }, grid: { color: gridColor } }
                }
            }
        });
    }
    
    // Store Type Distribution
    const storeTypeCtx = document.getElementById('storeTypeChart');
    if (storeTypeCtx) {
        const storeCounts = {};
        storeTypes.forEach(s => storeCounts[s] = allData.filter(d => d.jenisStore === s).length);
        
        new Chart(storeTypeCtx, {
            type: 'pie',
            data: {
                labels: storeTypes,
                datasets: [{
                    data: Object.values(storeCounts),
                    backgroundColor: ['#1FB8CD', '#FFC185', '#B4413C', '#ECEBD5']
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { labels: { color: textColor } } }
            }
        });
    }
}

// Filter Data
function filterData() {
    const month = document.getElementById('filterMonth').value;
    const dept = document.getElementById('filterDept').value;
    const branch = document.getElementById('filterBranch').value;
    const store = document.getElementById('filterStore').value;
    const status = document.getElementById('filterStatus').value;
    
    filteredData = allData.filter(record => {
        return (!month || record.bulan === month) &&
               (!dept || record.jabatan === dept) &&
               (!branch || record.cawangan === branch) &&
               (!store || record.jenisStore === store) &&
               (!status || record.status === status);
    });
    
    currentPage = 1;
    renderTable();
}

// Search
function handleSearch() {
    const query = document.getElementById('searchInput').value.toLowerCase();
    if (!query) {
        filteredData = [...allData];
    } else {
        filteredData = allData.filter(record => 
            Object.values(record).some(val => String(val).toLowerCase().includes(query))
        );
    }
    currentPage = 1;
    renderTable();
}

// Sort Table
function sortTable(column) {
    if (sortColumn === column) {
        sortDirection = sortDirection === 'asc' ? 'desc' : 'asc';
    } else {
        sortColumn = column;
        sortDirection = 'asc';
    }
    
    filteredData.sort((a, b) => {
        let aVal = a[column];
        let bVal = b[column];
        if (!isNaN(aVal) && !isNaN(bVal)) {
            aVal = Number(aVal);
            bVal = Number(bVal);
        }
        if (aVal < bVal) return sortDirection === 'asc' ? -1 : 1;
        if (aVal > bVal) return sortDirection === 'asc' ? 1 : -1;
        return 0;
    });
    
    renderTable();
}

// Render Table
function renderTable() {
    const tbody = document.getElementById('tableBody');
    const start = (currentPage - 1) * rowsPerPage;
    const end = start + rowsPerPage;
    const paginatedData = filteredData.slice(start, end);
    
    tbody.innerHTML = paginatedData.map(record => `
        <tr>
            <td class="checkbox-cell">
                <input type="checkbox" onchange="toggleRowSelection(${record.id})" ${selectedRows.has(record.id) ? 'checked' : ''}>
            </td>
            <td>
                <button class="star-btn ${record.starred ? 'starred' : ''}" onclick="toggleStar(${record.id})">
                    ${record.starred ? '⭐' : '☆'}
                </button>
            </td>
            <td>${record.bulan}</td>
            <td>${record.jabatan}</td>
            <td>${record.jenisStore}</td>
            <td>${record.promo}</td>
            <td>${record.slash}</td>
            <td>${record.cmp}</td>
            <td>${record.combo}</td>
            <td>${record.cawangan}</td>
            <td>${record.tempoh}</td>
            <td><span class="status-badge status-${record.status}">${getStatusText(record.status)}</span></td>
            <td>
                <button class="action-btn" onclick="editRecord(${record.id})">✏️</button>
                <button class="action-btn" onclick="deleteRecord(${record.id})">🗑️</button>
            </td>
        </tr>
    `).join('');
    
    updatePagination();
    updateBulkDeleteButton();
}

function getStatusText(status) {
    const map = { active: 'Aktif', pending: 'Menunggu', inactive: 'Tidak Aktif' };
    return map[status] || status;
}

function updatePagination() {
    const totalPages = Math.ceil(filteredData.length / rowsPerPage);
    document.getElementById('pageInfo').textContent = `Halaman ${currentPage} dari ${totalPages || 1}`;
    document.getElementById('prevBtn').disabled = currentPage === 1;
    document.getElementById('nextBtn').disabled = currentPage === totalPages || totalPages === 0;
}

function changePage(direction) {
    currentPage += direction;
    renderTable();
}

function toggleSelectAll() {
    const selectAll = document.getElementById('selectAll').checked;
    const start = (currentPage - 1) * rowsPerPage;
    const end = start + rowsPerPage;
    const paginatedData = filteredData.slice(start, end);
    
    if (selectAll) {
        paginatedData.forEach(record => selectedRows.add(record.id));
    } else {
        paginatedData.forEach(record => selectedRows.delete(record.id));
    }
    renderTable();
}

function toggleRowSelection(id) {
    if (selectedRows.has(id)) {
        selectedRows.delete(id);
    } else {
        selectedRows.add(id);
    }
    updateBulkDeleteButton();
}

function updateBulkDeleteButton() {
    document.getElementById('bulkDeleteBtn').style.display = selectedRows.size > 0 ? 'inline-flex' : 'none';
}

function toggleStar(id) {
    const record = allData.find(r => r.id === id);
    if (record) {
        record.starred = !record.starred;
        renderTable();
    }
}

function toggleCustomField(fieldName) {
    const select = document.getElementById(fieldName);
    const customGroup = document.getElementById(`custom${fieldName.charAt(0).toUpperCase() + fieldName.slice(1)}Group`);
    const customInput = document.getElementById(`custom${fieldName.charAt(0).toUpperCase() + fieldName.slice(1)}`);
    
    if (select.value === '__custom__') {
        customGroup.style.display = 'block';
        customInput.required = true;
    } else {
        customGroup.style.display = 'none';
        customInput.required = false;
        customInput.value = '';
    }
}

// Record CRUD
function openAddModal() {
    document.getElementById('modalTitle').textContent = 'Tambah Rekod Baru';
    document.getElementById('recordForm').reset();
    document.getElementById('recordId').value = '';
    document.getElementById('customJabatanGroup').style.display = 'none';
    document.getElementById('customJenisStoreGroup').style.display = 'none';
    document.getElementById('customCawanganGroup').style.display = 'none';
    document.getElementById('recordModal').classList.add('active');
}

function editRecord(id) {
    const record = allData.find(r => r.id === id);
    if (record) {
        document.getElementById('modalTitle').textContent = 'Edit Rekod';
        document.getElementById('recordId').value = record.id;
        document.getElementById('bulan').value = record.bulan;
        
        const jabatanField = document.getElementById('jabatan');
        if (departments.includes(record.jabatan)) {
            jabatanField.value = record.jabatan;
        } else {
            jabatanField.value = '__custom__';
            document.getElementById('customJabatanGroup').style.display = 'block';
            document.getElementById('customJabatan').value = record.jabatan;
        }
        
        const jenisStoreField = document.getElementById('jenisStore');
        if (storeTypes.includes(record.jenisStore)) {
            jenisStoreField.value = record.jenisStore;
        } else {
            jenisStoreField.value = '__custom__';
            document.getElementById('customJenisStoreGroup').style.display = 'block';
            document.getElementById('customJenisStore').value = record.jenisStore;
        }
        
        const cawanganField = document.getElementById('cawangan');
        if (branches.includes(record.cawangan)) {
            cawanganField.value = record.cawangan;
        } else {
            cawanganField.value = '__custom__';
            document.getElementById('customCawanganGroup').style.display = 'block';
            document.getElementById('customCawangan').value = record.cawangan;
        }
        
        document.getElementById('promo').value = record.promo;
        document.getElementById('slash').value = record.slash;
        document.getElementById('cmp').value = record.cmp;
        document.getElementById('combo').value = record.combo;
        document.getElementById('tempoh').value = record.tempoh;
        document.getElementById('status').value = record.status;
        document.getElementById('recordModal').classList.add('active');
    }
}

function saveRecord(event) {
    event.preventDefault();
    
    const id = document.getElementById('recordId').value;
    let jabatan = document.getElementById('jabatan').value;
    if (jabatan === '__custom__') jabatan = document.getElementById('customJabatan').value.trim();
    let jenisStore = document.getElementById('jenisStore').value;
    if (jenisStore === '__custom__') jenisStore = document.getElementById('customJenisStore').value.trim();
    let cawangan = document.getElementById('cawangan').value;
    if (cawangan === '__custom__') cawangan = document.getElementById('customCawangan').value.trim();
    
    const formData = {
        bulan: document.getElementById('bulan').value,
        jabatan,
        jenisStore,
        promo: document.getElementById('promo').value,
        slash: document.getElementById('slash').value,
        cmp: document.getElementById('cmp').value,
        combo: document.getElementById('combo').value,
        cawangan,
        tempoh: document.getElementById('tempoh').value,
        status: document.getElementById('status').value
    };
    
    if (id) {
        const index = allData.findIndex(r => r.id == id);
        if (index !== -1) {
            allData[index] = { ...allData[index], ...formData };
            addActivity(`Mengedit rekod: ${formData.bulan} - ${formData.jabatan}`);
        }
    } else {
        const newRecord = { id: Date.now(), ...formData, starred: false };
        allData.push(newRecord);
        addActivity(`Menambah rekod baru: ${formData.bulan} - ${formData.jabatan}`);
    }
    
    filteredData = [...allData];
    updateStats();
    renderTable();
    closeModal();
    showToast('Rekod berjaya disimpan!', 'success');
}

function deleteRecord(id) {
    if (confirm('Adakah anda pasti mahu memadam rekod ini?')) {
        const record = allData.find(r => r.id === id);
        allData = allData.filter(r => r.id !== id);
        filteredData = filteredData.filter(r => r.id !== id);
        selectedRows.delete(id);
        updateStats();
        renderTable();
        showToast('Rekod berjaya dipadam!', 'success');
        if (record) addActivity(`Memadam rekod: ${record.bulan} - ${record.jabatan}`);
    }
}

function bulkDelete() {
    if (selectedRows.size > 0 && confirm(`Padam ${selectedRows.size} rekod yang dipilih?`)) {
        allData = allData.filter(r => !selectedRows.has(r.id));
        filteredData = filteredData.filter(r => !selectedRows.has(r.id));
        selectedRows.clear();
        updateStats();
        renderTable();
        showToast('Rekod dipilih berjaya dipadam!', 'success');
    }
}

function closeModal() {
    document.getElementById('recordModal').classList.remove('active');
}

// Export
function exportToCSV() {
    const headers = ['Bulan', 'Jabatan', 'Jenis Store', 'Promo', 'Slash', 'CMP', 'Combo', 'Cawangan', 'Tempoh', 'Status'];
    const rows = filteredData.map(r => [
        r.bulan, r.jabatan, r.jenisStore, r.promo, r.slash, r.cmp, r.combo, r.cawangan, r.tempoh, r.status
    ]);
    
    let csvContent = headers.join(',') + '\n';
    rows.forEach(row => { csvContent += row.join(',') + '\n'; });
    
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `popcard_data_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
    showToast('Data berjaya dieksport!', 'success');
}

// Calendar
function renderCalendar() {
    const year = currentCalendarDate.getFullYear();
    const month = currentCalendarDate.getMonth();
    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const today = new Date();
    
    document.getElementById('currentMonthYear').textContent = `${monthsFull[month]} ${year}`;
    
    const grid = document.getElementById('calendarGrid');
    grid.innerHTML = '';
    
    // Day headers
    const dayHeaders = ['Min', 'Isn', 'Sel', 'Rab', 'Kha', 'Jum', 'Sab'];
    dayHeaders.forEach(day => {
        const header = document.createElement('div');
        header.className = 'calendar-day-header';
        header.textContent = day;
        grid.appendChild(header);
    });
    
    // Empty cells before first day
    for (let i = 0; i < firstDay; i++) {
        const empty = document.createElement('div');
        empty.className = 'calendar-day other-month';
        grid.appendChild(empty);
    }
    
    // Days
    for (let day = 1; day <= daysInMonth; day++) {
        const dayElement = document.createElement('div');
        dayElement.className = 'calendar-day';
        
        const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
        const dayTasks = allTasks.filter(t => t.date === dateStr);
        
        if (today.getDate() === day && today.getMonth() === month && today.getFullYear() === year) {
            dayElement.classList.add('today');
        }
        
        dayElement.innerHTML = `
            <div class="calendar-day-number">${day}</div>
            <div class="calendar-tasks">
                ${dayTasks.slice(0, 3).map(task => 
                    `<div class="task-badge task-color-${task.color}" onclick="editTask(${task.id})" title="${task.title}">${task.title.substring(0, 10)}...</div>`
                ).join('')}
                ${dayTasks.length > 3 ? `<div class="task-badge" style="background: var(--color-secondary);">+${dayTasks.length - 3}</div>` : ''}
            </div>
        `;
        
        dayElement.onclick = (e) => {
            if (!e.target.classList.contains('task-badge')) {
                openTaskModal(dateStr);
            }
        };
        
        grid.appendChild(dayElement);
    }
}

function changeMonth(direction) {
    currentCalendarDate.setMonth(currentCalendarDate.getMonth() + direction);
    renderCalendar();
}

function goToToday() {
    currentCalendarDate = new Date(2025, 11, 1);
    renderCalendar();
}

// Tasks
function openTaskModal(date = null) {
    document.getElementById('taskModalTitle').textContent = 'Tambah Tugas';
    document.getElementById('taskForm').reset();
    document.getElementById('taskId').value = '';
    if (date) {
        document.getElementById('taskDate').value = date;
    }
    updateColorPreview();
    document.getElementById('taskModal').classList.add('active');
}

function editTask(id) {
    const task = allTasks.find(t => t.id === id);
    if (task) {
        document.getElementById('taskModalTitle').textContent = 'Edit Tugas';
        document.getElementById('taskId').value = task.id;
        document.getElementById('taskDate').value = task.date;
        document.getElementById('taskTitle').value = task.title;
        document.getElementById('taskDescription').value = task.description || '';
        document.getElementById('taskColor').value = task.color;
        document.getElementById('taskTime').value = task.time || '';
        document.getElementById('taskPriority').value = task.priority;
        document.getElementById('taskCompleted').checked = task.completed;
        updateColorPreview();
        document.getElementById('taskModal').classList.add('active');
    }
}

function saveTask(event) {
    event.preventDefault();
    
    const id = document.getElementById('taskId').value;
    const taskData = {
        date: document.getElementById('taskDate').value,
        title: document.getElementById('taskTitle').value,
        description: document.getElementById('taskDescription').value,
        color: document.getElementById('taskColor').value,
        colorLabel: colorSystem[document.getElementById('taskColor').value].label,
        time: document.getElementById('taskTime').value,
        priority: document.getElementById('taskPriority').value,
        completed: document.getElementById('taskCompleted').checked
    };
    
    if (id) {
        const index = allTasks.findIndex(t => t.id == id);
        if (index !== -1) {
            allTasks[index] = { ...allTasks[index], ...taskData };
            addActivity(`Mengedit tugas: ${taskData.title}`);
        }
    } else {
        const newTask = { id: Date.now(), ...taskData };
        allTasks.push(newTask);
        addActivity(`Menambah tugas baru: ${taskData.title}`);
    }
    
    filteredTasks = [...allTasks];
    updateStats();
    renderCalendar();
    renderTasksList();
    closeTaskModal();
    showToast('Tugas berjaya disimpan!', 'success');
}

function deleteTask(id) {
    if (confirm('Adakah anda pasti mahu memadam tugas ini?')) {
        const task = allTasks.find(t => t.id === id);
        allTasks = allTasks.filter(t => t.id !== id);
        filteredTasks = filteredTasks.filter(t => t.id !== id);
        updateStats();
        renderCalendar();
        renderTasksList();
        showToast('Tugas berjaya dipadam!', 'success');
        if (task) addActivity(`Memadam tugas: ${task.title}`);
    }
}

function closeTaskModal() {
    document.getElementById('taskModal').classList.remove('active');
}

function updateColorPreview() {
    const color = document.getElementById('taskColor').value;
    const preview = document.getElementById('colorPreview');
    preview.style.backgroundColor = colorSystem[color].hex;
    preview.style.color = color === 'yellow' ? '#000' : '#fff';
    preview.textContent = `${getColorEmoji(color)} ${colorSystem[color].label} - ${colorSystem[color].meaning}`;
}

function filterTasks() {
    const colorFilter = document.getElementById('taskColorFilter').value;
    const priorityFilter = document.getElementById('taskPriorityFilter').value;
    const searchQuery = document.getElementById('taskSearchInput').value.toLowerCase();
    
    filteredTasks = allTasks.filter(task => {
        return (!colorFilter || task.color === colorFilter) &&
               (!priorityFilter || task.priority === priorityFilter) &&
               (!searchQuery || task.title.toLowerCase().includes(searchQuery) || 
                (task.description && task.description.toLowerCase().includes(searchQuery)));
    });
    
    renderTasksList();
}

function renderTasksList() {
    const list = document.getElementById('tasksList');
    const sortedTasks = [...filteredTasks].sort((a, b) => {
        if (a.completed !== b.completed) return a.completed ? 1 : -1;
        return new Date(a.date) - new Date(b.date);
    });
    
    if (sortedTasks.length === 0) {
        list.innerHTML = '<div style="text-align: center; padding: 40px; color: var(--color-text-secondary);">Tiada tugas dijumpai</div>';
        return;
    }
    
    list.innerHTML = sortedTasks.map(task => `
        <div class="task-item priority-${task.priority.toLowerCase()} ${task.completed ? 'completed' : ''}" style="border-left-color: ${colorSystem[task.color].hex};">
            <div class="task-info">
                <div class="task-title ${task.completed ? 'completed' : ''}">${task.title}</div>
                <div class="task-meta">
                    <span>📅 ${task.date}</span>
                    ${task.time ? `<span>🕐 ${task.time}</span>` : ''}
                    <span style="background: ${colorSystem[task.color].hex}; padding: 2px 8px; border-radius: 4px; font-size: 10px; color: ${task.color === 'yellow' ? '#000' : '#fff'};">${getColorEmoji(task.color)} ${task.colorLabel}</span>
                    <span>🎯 ${task.priority}</span>
                </div>
            </div>
            <div class="task-actions">
                <button class="action-btn" onclick="editTask(${task.id})" title="Edit">✏️</button>
                <button class="action-btn" onclick="deleteTask(${task.id})" title="Padam">🗑️</button>
            </div>
        </div>
    `).join('');
}

// Settings
function renderColorSettings() {
    const container = document.getElementById('colorLabelsSettings');
    container.innerHTML = Object.keys(colorSystem).map(color => `
        <div class="color-label-item">
            <div class="color-sample" style="background: ${colorSystem[color].hex};"></div>
            <div style="flex: 1;">
                <strong>${getColorEmoji(color)} ${colorSystem[color].label}</strong>
                <div style="font-size: var(--font-size-xs); color: var(--color-text-secondary);">${colorSystem[color].meaning}</div>
            </div>
        </div>
    `).join('');
}

function saveSettings() {
    showToast('Tetapan berjaya disimpan!', 'success');
}

// Activity Feed
function addActivity(message) {
    const now = new Date();
    const timeStr = now.toLocaleTimeString('ms-MY', { hour: '2-digit', minute: '2-digit' });
    recentActivity.unshift({ message, time: timeStr });
    if (recentActivity.length > 5) recentActivity.pop();
    updateActivityFeed();
}

function updateActivityFeed() {
    const feed = document.getElementById('activityFeed');
    if (recentActivity.length === 0) {
        feed.innerHTML = '<div class="activity-item">Tiada aktiviti terkini</div>';
    } else {
        feed.innerHTML = recentActivity.map(activity => `
            <div class="activity-item">
                ${activity.message}
                <div class="activity-time">${activity.time}</div>
            </div>
        `).join('');
    }
}

// Theme
function toggleTheme() {
    const currentTheme = document.documentElement.getAttribute('data-color-scheme');
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-color-scheme', newTheme);
    addActivity(`Menukar tema ke ${newTheme === 'dark' ? 'gelap' : 'cerah'}`);
}

function loadTheme() {
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    document.documentElement.setAttribute('data-color-scheme', prefersDark ? 'dark' : 'light');
}

// Toast
function showToast(message, type = 'success') {
    const toast = document.getElementById('toast');
    toast.textContent = message;
    toast.className = `toast ${type} active`;
    setTimeout(() => toast.classList.remove('active'), 3000);
}

// Print Function
function printLaporan() {
    const activePage = document.querySelector('.page.active');
    const pageId = activePage.id;
    
    // Add print date to header
    const now = new Date();
    const dateStr = now.toLocaleDateString('ms-MY', { 
        day: '2-digit', 
        month: 'long', 
        year: 'numeric' 
    });
    const timeStr = now.toLocaleTimeString('ms-MY', { 
        hour: '2-digit', 
        minute: '2-digit' 
    });
    
    const pageHeader = activePage.querySelector('.page-header');
    if (pageHeader) {
        pageHeader.setAttribute('data-print-date', `${dateStr}, ${timeStr}`);
    }
    
    // Prepare print title based on page
    let printTitle = 'LAPORAN SISTEM POP CARD';
    if (pageId === 'dashboardPage') {
        printTitle = `LAPORAN PAPAN PEMUKA - ${dateStr}`;
    } else if (pageId === 'popcardPage') {
        printTitle = `LAPORAN DATA POP CARD - ${dateStr}`;
    } else if (pageId === 'calendarPage') {
        const monthYear = document.getElementById('currentMonthYear').textContent;
        printTitle = `LAPORAN JEJAK BAKAL TUGAS - ${monthYear}`;
    } else if (pageId === 'analyticsPage') {
        printTitle = `LAPORAN ANALITIK - ${dateStr}`;
    } else if (pageId === 'settingsPage') {
        printTitle = `LAPORAN KONFIGURASI SISTEM - ${dateStr}`;
    }
    
    // Store original title
    const originalTitle = document.title;
    document.title = printTitle;
    
    // Add activity
    addActivity(`Mencetak laporan: ${printTitle}`);
    
    // Show toast notification
    showToast('Membuka tetingkap cetak...', 'success');
    
    // Trigger browser print dialog
    setTimeout(() => {
        window.print();
        
        // Restore original title after print
        document.title = originalTitle;
    }, 300);
}

// Get current active page name
function getCurrentPageName() {
    const activePage = document.querySelector('.page.active');
    if (!activePage) return 'Dashboard';
    
    const pageId = activePage.id;
    const pageNames = {
        'dashboardPage': 'Papan Pemuka',
        'popcardPage': 'Data POP CARD',
        'calendarPage': 'Jejak Bakal Tugas',
        'analyticsPage': 'Analitik',
        'settingsPage': 'Tetapan'
    };
    
    return pageNames[pageId] || 'Dashboard';
}

// Initialize
window.addEventListener('DOMContentLoaded', () => {
    init();
    initDashboardCharts();
});